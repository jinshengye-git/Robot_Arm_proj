# 1. overview
This document mainly introduces the functions of the Orbbec SDK Python Wrapper. The Orbbec SDK Python Wrapper is designed and packaged based on the Orbbec SDK, and mainly realizes how to get data stream and device command control. <br />
In order to enable users to quickly access Orbbec SDK Python Wrapper SDK in their own projects correctly and efficiently, and prevent other problems caused by non-standard calls in the process of using related APIs, this document is drawn up to standardize API calls.<br />​

**version requirements：**<br />Python：3.7/3.8/3.9<br />numpy：1.21.0 and above<br />opencv-python：4.2.0 and above<br />​

**System Requirements：**<br />Windows：Windows 10 (x64)<br />Linux: Ubuntu 16.04/18.04/20.04 (x64)<br />​<br />
# 2. Orbbec SDK Python Wrapper Sample Compilation instructions
## 2.1 Windows development environment
<br />1. Take python3.7 as an example, download version 3.7.7 from the official website[https://www.python.org/downloads/release/python-377/](https://www.python.org/downloads/release/python-377/)（other versions are also available）<br />![image.png](image1.png)<br />2. Install python3.7.7, then install numpy and opencv-python
```
pip3 install opencv-python
pip3 install numpy
```

In addition, you can also specify the version and download it through the server mirror, such as specifying the numpy version as 1.21.5 and the opencv-python version as 4.5.4.60. The server mirror website is [http://mirrors.aliyun.com/pypi/simple/](http://mirrors.aliyun.com/pypi/simple/), you can also specify other server mirror websites, the purpose is to improve downloading speed.

```
pip3 install numpy==1.21.5 -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
pip3 install opencv-python==4.5.4.60 -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
```

<br />3. Copy lib/python_lib/*.pyd and /lib/c_lib/*.dll to the Samples directory​
<br />4. Execute test examples such as python ColorViewer.py in the Samples directory
## 2.2 Linux development environment
<br />1. Take python3.7 as an example, download and install version 3.7.7 <br />（1）These libs need to be installed before installing python3.7.7
```
sudo apt-get install libffi-dev	
sudo apt-get install zlib1g-dev libbz2-dev libssl-dev libncurses5-dev libsqlite3-dev
```
（2）Download Python-3.7.7
```
wget https://www.python.org/ftp/python/3.7.7/Python-3.7.7.tgz
```
（3）decompress
```
tar -vxf Python-3.7.7.tgz
```
（4）Enter the decompressed Python-3.7.7 directory
```
cd Python-3.7.7
```
（5）Create the installation directory of python3.7.7
```
sudo mkdir -p /usr/local/python3.7
```
（6）Configuration
```
./configure --prefix=/usr/local/python3.7/
```
（7）Compile
```
make
```
（8）Install
```
sudo make install
```
（9）Create python3.7 and pip3 soft link
```
sudo ln -s /usr/local/python3.7/bin/python3.7 /usr/bin/python3.7
sudo rm /usr/bin/pip3	 #Delete the pip3 soft link of the original version to avoid conflicts
sudo ln -s /usr/local/python3.7/bin/pip3 /usr/bin/pip3
```
<br />2. Install numpy and opencv-python
```
sudo pip3 install opencv-python
sudo pip3 install numpy
```
In addition, you can also specify the version and download it through the server mirror, such as specifying the numpy version as 1.21.5 and the opencv-python version as 4.2.0.32. The server mirror website is [http://mirrors.aliyun.com/pypi/simple/](http://mirrors.aliyun.com/pypi/simple/), you can also specify other server mirror websites, the purpose is to improve downloading speed.
```
sudo pip3 install numpy==1.21.5 -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
sudo pip3 install opencv-python==4.2.0.32 -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
```
<br />3. Create a soft link to the dependent library that the sample runs on
```
sudo ln -s absolute path/lib/c_lib/libOrbbecSDK.so.1.5.7 /usr/lib/
sudo ln -s absolute path/lib/c_lib/libOrbbecSDK.so.1.5 /usr/lib/
sudo ln -s absolute path/lib/c_lib/libOrbbecSDK.so /usr/lib/
```

<br />4. Copy lib/python_lib/*.so to the Samples directory​
<br />5. Execute test examples in the Samples directory (python should use the corresponding version)<br />​
such as <br/>sudo python3.7 ColorViewer.py <br />
# 3. Common call process
## 3.1 Video data acquisition
First of all, we need to create a Pipeline, through which it is easy to open and close various types of streams and obtain a set of frame data
```
pipe = Pipeline.Pipeline(None, None)
```
Get all stream configurations of a color camera, including stream resolution, frame rate, and frame format
```
profiles = pipe.getStreamProfileList( Pipeline.OB_PY_SENSOR_COLOR )

#Get the frame format to use by traversing the configuration of the color stream, here the MJPG format will be used to open the stream
count = profiles.count()
for i in range( count ):
	profile = profiles.getProfile( i )
	videoProfile = profile.toViedo()
	if videoProfile.format() == StreamProfile.PY_FORMAT_MJPG:
		colorProfile = videoProfile
		break
```
Configure which streams to enable or disable for the Pipeline by creating a Config, where colored streams will be enabled
```
config = Pipeline.Config()
config.enableStream( colorProfile )
```
Start the flow configured in Config, if no parameters are passed, the default configuration startup flow will be started
```
pipe.start( config, None)
```
Wait for a frame of data in a blocking mode. This frame is a composite frame that contains frame data of all streams enabled in the configuration, and set the frame waiting timeout to 100ms
```
frameSet = pipe.waitForFrames( 100 )
```
Stopping the Pipeline 
```
pipe.stop()
```
## 3.2 Sensor Param Set

First of all, we need to create a Context to obtain a list of device information, read and write device properties
```
	ctx = Context.Context( None )
```
Query the list of connected devices
```
	deviceList = ctx.queryDeviceList();
```
select a device
```
device = selectDevice( deviceList )
```
select a sensor
```
Sensor = selectSensor( device )
```
 Device control
```
getPropertyValue(device, propertyItem)
setPropertyValue(device, propertyItem, propertyValue)
```
# 4. API interface introduction
## 4.1 Context API

The SDK context class, the entry point of the Orbbec SDK, is used to obtain the device list, handle device callbacks, and set the log level.
### 4.1.1 Context Class

Context is a management class that describes the runtime of the SDK. It is responsible for the resource application and release of the SDK. The context has the ability to manage multiple devices, and is responsible for enumerating devices, monitoring device callbacks, and enabling multi-device synchronization.
<br />​<br />
```
class Context:
	Methods defined here:
	queryDeviceList(...)    
	setDeviceChangedCallback(...)    
	setLoggerServerity(...)    
	setLoggerToFile(...)    
	setLoggerToConsole(...)    
	enableMultiDeviceSync(...)
```
#### 4.1.1.1 init function
**Functional description**
<br />Function function: create a Context object。
<br />parameter：<br />[in] configPath：The path to the configuration file（The configuration file is OrbbecSDKConfig_v1.0.xml）。
<br />Return value: return the Context object。
<br />**call the API**
```
Context( configPath )
```
**code example**
```
Create a Context object and specify the configuration file path：
configDir = b'D:/config/'
ctx = Context.Context( configDir)
Create a Context object without specifying the configuration file path：
ctx = Context.Context( None )
```
#### 4.1.1.2 queryDeviceList function
**Functional description**
<br />Function function: get enumeration to device list。
<br />Return value: return device list, data type：class DeviceList。
<br />**call the API**
```
queryDeviceList()
```
**code example**
```
ctx = Context.Context( None )
devList = ctx.queryDeviceList()
```
#### 4.1.1.3 setDeviceChangedCallback function
**Functional description**
<br />Function function: set the callback function for device plugging and unplugging.。
<br />parameter：<br />[in] callback : The callback function triggered when the device is plugged and unplugged。
<br />Return value: None。
<br />**call the API**
```
setDeviceChangedCallback( callback )
```
**code example**
```
def callback( removedList, addedList ):
	if removedList != None:
		DeviceDisconnectCallback( removedList )
	if addedList != None:
		DeviceConnectCallback( addedList )
	print("hotplug event")
ctx = Context.Context( None )
ctx.setDeviceChangedCallback( callback )
```
#### 4.1.1.4 setLoggerServerity function
**Functional description**
<br />Function function: set the output level of the log。
<br />parameter：<br />[in] log，Log output level, data type：enum ob_py_log_severity
```
OB_PY_LOG_SEVERITY_DEBUG = 0
OB_PY_LOG_SEVERITY_INFO = 1
OB_PY_LOG_SEVERITY_WARN = 2
OB_PY_LOG_SEVERITY_ERROR = 3
OB_PY_LOG_SEVERITY_FATAL = 4
OB_PY_LOG_SEVERITY_NONE = 5
OB_PY_LOG_SEVERITY_COUNT = 6
```
<br />Return value: None。
<br />**call the API**
```
setLoggerServerity( log )
```
**code example**
```
ctx = Context.Context( None )
ctx.setLoggerServerity( Context.OB_PY_LOG_SEVERITY_INFO)
```
#### 4.1.1.5 setLoggerToFile function
**Functional description**
<br />Function function: set log output to file。
<br />parameter：<br />[in] log: Log output level, data type:enum ob_py_log_severity
```
OB_PY_LOG_SEVERITY_DEBUG = 0
OB_PY_LOG_SEVERITY_INFO = 1
OB_PY_LOG_SEVERITY_WARN = 2
OB_PY_LOG_SEVERITY_ERROR = 3
OB_PY_LOG_SEVERITY_FATAL = 4
OB_PY_LOG_SEVERITY_NONE = 5
OB_PY_LOG_SEVERITY_COUNT = 6
```
[in] fileName:  log file path
<br />Return value: None。
<br />**call the API**
```
setLoggerToFile( log, fileName )
```
**code example**
```
ctx = Context.Context( None )
logDir =b'D:/LOG/'
ctx.setLoggerToFile( Context.OB_PY_LOG_SEVERITY_INFO，logDir )
```
#### 4.1.1.6 setLoggerToConsole function
**Functional description**
<br />Function function: set the log output to the terminal。
<br />parameter：<br />[in] log: Log output level, data type:enum ob_py_log_severity
```
OB_PY_LOG_SEVERITY_DEBUG = 0
OB_PY_LOG_SEVERITY_INFO = 1
OB_PY_LOG_SEVERITY_WARN = 2
OB_PY_LOG_SEVERITY_ERROR = 3
OB_PY_LOG_SEVERITY_FATAL = 4
OB_PY_LOG_SEVERITY_NONE = 5
OB_PY_LOG_SEVERITY_COUNT = 6
```
Return value: None。<br />
<br />**call the API**
```
setLoggerToConsole( log )
```
**code example**
```
ctx = Context.Context( None )
ctx.setLoggerToConsole( Context.OB_PY_LOG_SEVERITY_INFO )
```
#### 4.1.1.7 enableMultiDeviceSync function
**Functional description**
<br />Function function: start the multi-device synchronization function。
<br />parameter：<br />[in] repeatInterval: Timing synchronization time interval (in ms; if repeatInterval=0, it means only one synchronization is performed)）。
<br />Return value: None。<br />
**call the API**
```
enableMultiDeviceSync( repeatInterval )
```
**code example**
```
ctx = Context.Context( None )
ctx.enableMultiDeviceSync( 0 )
```
## 4.2 Device API

Device-related APIs, including obtaining and creating devices, setting and obtaining device properties, get sensors, etc.
### 4.2.1 Device Class
An entity describing an RGBD camera, representing a specific device of an RGBD camera
```
class Device:
	Methods defined here:
	getDeviceInfo(...)
	getSensorList(...)
	getSensor(...)
	setIntProperty(...)
	setFloatProperty(...)
	setBoolProperty(...)
	getIntProperty(...)
	getFloatProperty(...)
	getBoolProperty(...)
	getIntPropertyRange(...)
	getFloatPropertyRange(...)
	getBoolPropertyRange(...)
	getSupportedPropertyCount(...)
	getSupportedProperty(...)
	isPropertySupported(...)
	syncDeviceTime(...)
	getDeviceState(...)
	setDeviceStateChangedCallback(...)
    getCalibrationCameraParamList(...)
```
#### 4.2.1.1 getDeviceInfo function
**Functional description**
<br />Function function: get device information.
<br />Return value: return device information, data type:class DeviceInfo。
<br />**call the API**
```
getDeviceInfo()
```
**code example**
```
ctx = Context.Context( None )
devList = ctx.queryDeviceList()
dev = devList.getDevice( 0 )
devInfo = dev.getDeviceInfo()
```
#### 4.2.1.2 getSensorList function
**Functional description**
<br />Function function: Get the device sensor list.
<br />Return value: return sensor list, data type: class SensorList。
<br />**call the API**
```
getSensorList()
```
**code example**
```
sensorList= dev.getSensorList() 
```
#### 4.2.1.3 getSensor function
**Functional description**
<br />Function function: Get the specified type of sensor.
<br />parameter：<br />[in] sensorType: sensor type, data type：enum ob_py_sensor_type:<br />	OB_PY_SENSOR_UNKNOWN = 0<br />	OB_PY_SENSOR_IR      = 1<br />	OB_PY_SENSOR_COLOR   = 2<br />	OB_PY_SENSOR_DEPTH   = 3
<br />Return value: return the Sensor object, if the device does not have the device, return None, data type：class Sensor。<br />
**call the API**
```
getSensor( sensorType)
```
**code example**
```
sensor = dev.getSensor( Device.OB_PY_SENSOR_COLOR ) 
```
#### 4.2.1.4 setIntProperty function
**Functional description**
<br />Function function: set the device attribute of int type
<br />parameter：<br />[in] propertyId: property id，data type: enum ob_py_property_id.
<br />[in] property: value，data type：int。
<br />Return value: None<br />
**call the API**
```
setIntProperty( propertyId, property )
```
**code example**
```
dev.setIntProperty( Device.OB_PY_PROP_DEPTH_MAX_DIFF_INT, 16 ) 
```
#### 4.2.1.5 setFloatProperty function
**Functional description**
<br />Function function: set the device attribute of float type。
<br />parameter：
<br />[in] propertyId: property id，data type: enum ob_py_property_id
<br />[in] property: value，data type：float。
<br />Return value: None<br />
**call the API**
```
setFloatProperty( propertyId, property )
```

#### 4.2.1.6 setBoolProperty function
**Functional description**
<br />Function function: set the device attribute of bool type。
<br />parameter：
<br />[in] propertyId: property id，data type：enum ob_py_property_id
<br />[in] property: value，data type：bool。
<br />Return value: None<br />
**call the API**
```
setBoolProperty( propertyId, property )
```
**code example**
```
dev.setBoolProperty( Device.OB_PY_PROP_COLOR_MIRROR_BOOL, 0 ) 
```
#### 4.2.1.7 getIntProperty function
**Functional description**
<br />Function function: Get the device attribute of int type.
<br />parameter：
<br />[in] propertyId: property id，data type：enum ob_py_property_id
<br />Return value: return the acquired attribute data, data type：int。<br />
**call the API**
```
getIntProperty( propertyId )
```
**code example**
```
intProperty = dev.getIntProperty( Device.OB_PY_PROP_DEPTH_MAX_DIFF_INT ) 
```
#### 4.2.1.8 getFloatProperty function
**Functional description**
<br />Function function: Get the device attribute of float type.
<br />parameter：
<br />[in] propertyId: property id，data type：enum ob_py_property_id。
<br />Return value: return the acquired attribute data, data type：float。<br />
**call the API**
```
getFloatProperty( propertyId )
```

#### 4.2.1.9 getBoolProperty function
**Functional description**
<br />Function function: Get the device attribute of bool type.
<br />parameter：
<br />[in] propertyId: property id，data type：enum ob_py_property_id.
<br />Return value: return the acquired attribute data, data type：bool。<br />

**call the API**
```
getBoolProperty( propertyId )
```
**code example**
```
boolProperty = dev.getBoolProperty( Device.OB_PY_PROP_COLOR_MIRROR_BOOL ) 
```
#### 4.2.1.10 getIntPropertyRange function
**Functional description**
<br />Function function: Get the range of device properties of type int (including the current value)。
<br />parameter：<br />[in] propertyId: property id，data type：enum ob_py_property_id 
<br />Return value: range of attributes, data type: dictionary{'cur':value1,'max':value2,'min':value3,'step':value4}。<br />
**call the API**
```
getIntPropertyRange( propertyId )
```
**code example**
```
propertyRange = dev.getIntPropertyRange( Device.OB_PY_PROP_DEPTH_MAX_DIFF_INT )
print( "range([ %d - %d ],step:%d )" %( propertyRange.get( "min" ), propertyRange.get( "max" ), propertyRange.get( "step" ) ) ) 
```
#### 4.2.1.11 getFloatPropertyRange function
**Functional description**
<br />Function function: Get the range of device properties of float type (including the current value)。
<br />parameter：
<br />[in] propertyId: property id，data type：enum ob_py_property_id 
<br />Return value: range of attributes, data type: dictionary{'cur':value1,'max':value2,'min':value3,'step':value4}。<br />
**call the API**
```
getFloatPropertyRange( propertyId )
```

#### 4.2.1.12 getBoolPropertyRange function
**Functional description**
<br />Function function: Get the range of bool type device properties (including the current value)。
<br />parameter：
<br />[in] propertyId: property id，data type：enum ob_py_property_id.
<br />Return value: range of attributes, data type: dictionary{'cur':value1,'max':value2,'min':value3,'step':value4}。<br />
**call the API**
```
getBoolPropertyRange( propertyId )
```
**code example**
```
propertyRange = dev.getBoolPropertyRange( Device.PY_DEVICE_PROPERTY_COLOR_MIRROR_BOOL )
print( "range([ %d - %d ],step:%d )" %( propertyRange.get( "min" ), propertyRange.get( "max" ), propertyRange.get( "step" ) ) ) 
```
#### 4.2.1.13 getSupportedPropertyCount function
**Functional description**<br />Function function: Get the number of attributes supported by the device。<br />parameter：<br />[in] None。<br />Return value: returns the number of supported attributes, data type：int。<br />**call the API**
```
getSupportedPropertyCount()
```
**code example**
```
num = dev.getSupportedPropertyCount() 
```
#### 4.2.1.14 getSupportedProperty function
**Functional description**<br />Function function: Get the attributes supported by the device<br />parameter：<br />[in] index:attribute index, data type：int。<br />Return value: Returns the type of supported property<br />**call the API**
```
getSupportedProperty( index )
```
**code example**
```
propertyItem = dev.getSupportedProperty( 0 )
print( "id= %d  name= %s  type= %d )" %( propertyItem.get( "id" ), propertyItem.get( "name" ), propertyItem.get( "type" ) ) ) 
```
#### 4.2.1.15 isPropertySupported function
**Functional description**<br />Function: determine whether the attribute permission of the device supports<br />parameter：<br />[in] propertyId: property id。<br/>[in] permission:  The type of read and write permissions<br />Return value: True supports this property, False does not support this property.。<br />**call the API**
```
isPropertySupported( propertyId,permission )
```
**code example**
```
isSupported= dev.isPropertySupported(OB_PY_PROP_IR_MIRROR_BOOL, OB_PY_PERMISSION_WRITE)
```
#### 4.2.1.16 syncDeviceTime function
**Functional description**<br />Function function: Synchronize device time (send time to device, synchronize local system time to device)。<br />parameter：<br />[in] None。<br />Return value: Command round-trip time delay（round trip time， rtt），data type：unsigned long long。<br />**call the API**
```
syncDeviceTime()
```
**code example**
```
delayTime= dev.syncDeviceTime() 
```
#### 4.2.1.17 getDeviceState function
**Functional description**<br />Function function: get the current device status。<br />parameter：<br />[in] None。<br />Return value: device status information, data type: dictionary{'type':value1,'msg':value2}，value1 is 0 means NORMAL, value1 is 1 means OPEN_STREAM_OPERATION_ERROR。<br />**call the API**
```
getDeviceState()
```
**code example**
```
devState= dev.getDeviceState() 
print("type:",devState.get("type"))
print("msg:",devState.get("msg"))
```
#### 4.2.1.18 setDeviceStateChangedCallback function
**Functional description**<br />Function function: set the device state change callback function。<br />parameter：<br />[in] callback: The callback function triggered when the device status changes (for example, the frame rate is automatically reduced due to high temperature or the flow is turned off, etc.), python defines the callback function as:    def callback( devState)devState is of type dictionary{'type':value1,'msg':value2}，value1 is 0 means NORMAL, value1 is 1 means open flow exception（OPEN_STREAM_OPERATION_ERROR）。<br />Return value: None。<br />**call the API**
```
setDeviceStateChangedCallback( callback )
```
**code example**
```
def callback( devState ):
	if devState != None:
print("type:",devState.get("type"))
print("msg:",devState.get("msg"))
ctx = Context.Context( None )
devList = ctx.queryDeviceList()
dev = devList.getDevice( 0 )
delayTime= dev.setDeviceStateChangedCallback( callback )
```

#### 4.2.1.18 getCalibrationCameraParamList function
**Functional description**<br />Function function: Get the original parameter list of the camera calibration saved in the device. The parameters in the list do not correspond to the current open stream configuration. You need to select the parameters according to the actual situation and may need to do scaling, mirroring and other processing. Non-professional users are recommended to use the Pipeline::getCameraParam() interface.
<br /> Return value: CameraParamList： camera parameter list

**call the API**
```
cameraParamList =getCalibrationCameraParamList()
```

### 4.2.2 DeviceInfo Class
A class that describes device information, representing the name, id, serial number and other basic information of the device itself of an RGBD camera.<br />class DeviceInfo :<br />Methods defined here:<br />	name(...)<br />	pid(...)<br />	vid(...)<br />	uid(...)<br />	serialNumber(...)<br />	firmwareVersion(...)<br />	usbType(...)
#### 4.2.2.1 name function
**Functional description**<br />Function function: get the device name<br />parameter：<br />[in] None。<br />Return value: return device name<br />**call the API**
```
name()
```
**code example**
```
ctx = Context.Context( None )
devList = ctx.queryDeviceList()
dev = devList.getDevice( 0 )
devInfo = dev.getDeviceInfo()
devName = devInfo.name()
```
#### 4.2.2.2 pid function
**Functional description**<br />Function function: get the pid of the device.<br />parameter：<br />[in] None。<br />Return value: return the pid of the device, data type: int <br />**call the API**
```
pid()
```
**code example**
```
pid = devInfo.pid()  
```
#### 4.2.2.3 vid function
**Functional description**<br />Function function: get the vid of the device。<br />parameter：<br />[in] Node。<br />Return value: return the vid of the device, data type: int<br />**call the API**
```
vid()
```
**code example**
```
vid = devInfo.vid()  
```
#### 4.2.2.4 uid function
**Functional description**<br />Function function: get the uid of the device。<br />parameter：<br />[in] None。<br />Return value: return the vid of the device<br />**call the API**
```
uid()
```
**code example**
```
uid = devInfo.uid() 
```
#### 4.2.2.5 serialNumber function
**Functional description**<br />Function function: get the serial number of the device.<br />parameter：<br />[in] None。<br />Return value: return the serial number of the device, data type：class bytes。<br />**call the API**
```
serialNumber()
```
**code example**
```
sn = devInfo.serialNumber()  
```
#### 4.2.2.6 firmwareVersion function
**Functional description**<br />Function function: get the version number of the firmware. <br />parameter：<br />[in] None。<br />Return value: return the version number of the firmware, data type：class bytes。<br />**call the API**
```
firmwareVersion()
```
**code example**
```
version = devInfo.firmwareVersion()  
```
#### 4.2.2.7 usbType function
**Functional description**<br />Function function: get usb connection type <br />parameter：<br />[in] None。<br />Return value: return usb connection type, data type：class bytes。<br />**call the API**
```
usbType()
```
**code example**
```
usbType = devInfo.usbType()  
```
### 4.2.3 DeviceList Class
A class describing a list of devices.
```
class DeviceList :
	Methods defined here:
	deviceCount(...)
	name(...)
	pid(...)
	vid(...)
	uid(...)
	getDevice(...)

```
#### 4.2.3.1 deviceCount function
**Functional description**<br />Function function: get the number of devices<br />parameter：<br />[in] None。<br />Return value: return the number of devices, data type：int。<br />**call the API**
```
deviceCount()
```
**code example**
```
ctx = Context.Context( None )
devList = ctx.queryDeviceList()
devNum = devList.deviceCount()
```
#### 4.2.3.2 name function
**Functional description**<br />Function function: get the name of the specified device <br />parameter：<br />[in] index: device index，data type：int。<br />Return value: return the name of the device, data type：class bytes。<br />**call the API**
```
name( index )
```
**code example**
```
ctx = Context.Context( None )
devList = ctx.queryDeviceList()
name = devList.name( 0 )
```
#### 4.2.3.3 pid function
**Functional description**<br />Function function: get the pid of the device<br />parameter：<br />[in] index:  device index，data type：int。<br />Return value: return the pid of the device, data type：int。<br />**call the API**
```
pid( index )
```
**code example**
```
ctx = Context.Context( None )
devList = ctx.queryDeviceList()
pid = devList.pid( 0 )
```
#### 4.2.3.4 vid function
**Functional description**<br />Function function: get the vid of the device<br />parameter：<br />[in] index:  device index，data type：int<br />Return value: return the vid of the device, data type：int。<br />**call the API**
```
vid( index )
```
**code example**
```
ctx = Context.Context( None )
devList = ctx.queryDeviceList()
vid = devList.vid( 0 )
```
#### 4.2.3.5 uid function
**Functional description**<br />Function function: get the uid of the device<br />parameter：<br />[in] index: device index，data type：int。<br />Return value: return the uid of the device, data type:class bytes。<br />**call the API**
```
uid( index )
```
**code example**
```
ctx = Context.Context( None )
devList = ctx.queryDeviceList()
uid = devList.uid( 0 )
```
#### 4.2.3.6 getDevice function
**Functional description**<br />Function function: Obtain the device object from the device list. If the device has been created , repeated acquisition will throw an exception。<br />parameter：<br />[in] index: device index，data type：int。<br />Return value: return device object, data type：class Device。<br />**call the API**
```
getDevice( index )
```
**code example**
```
ctx = Context.Context( None )
devList = ctx.queryDeviceList()
dev = devList.getDevice( 0 )
```
#### 4.2.3.7 getDeviceBySN function
**Functional description**<br />Function function: get the device object through the serial number<br />parameter：<br />[in] serialNumber:Device serial number, parameter type: const char *<br />Return value: return device object, data type：class Device。<br />**call the API**
```
getDeviceBySN(serialNumber)
```
### 4.2.4 CameraParamList Class
```
class CameraParamList :
	Methods defined here:
    count(...)
	getCameraParam(...)

```

#### 4.2.4.1 count function
**Functional description**<br />Function function: get the group number of camera parameters<br />Return value: Returns the number of camera parameter groups。<br />**call the API**
```
count()
```

#### 4.2.4.2 getCameraParam function
**Functional description**<br />Function function: get camera parameters<br />parameter：index :camera param index <br/>Return value: ob_camera_param returns the corresponding camera parameter。<br />**call the API**
```
getCameraParam(index)
```

## 4.3 Error API

### 4.3.1 ObException class
Describes the abnormal errors inside the SDK, through which the detailed information of the exception can be obtained.
```
class ObException:
	Methods defined here:
	getMessage(...)
	getExceptionType(...)
	getName(...)
	getArgs(...)
	getStatus(...)
```
#### 4.3.1.1 getMessage function
**Functional description**<br />Function function: Get detailed error logs of SDK internal exceptions。<br />parameter：<br />[in] None。<br />Return value: return error log, data type：class bytes。<br />**call the API**
```
getMessage()
```
**code example**
```
try:
ctx = Context.Context( None )
except ObException as e:
    print( "function: %s\nargs: %s\nmessage: %s\ntype: %d\nstatus: %d" %( e.getName(), e.getArgs(), e.getMessage(), e.getExceptionType(), e.getStatus() ) )
```
#### 4.3.1.2 getExceptionType function
**Functional description**<br />Function: Get the exception type of the error, and judge which module is abnormal。<br />parameter：<br />[in] None。<br />Return value: return exception type, data type：enum ob_exception_type。
```
OB_EXCEPTION_TYPE_UNKNOWN          =0     #Unknown error, an error not clearly defined by the SDK
OB_EXCEPTION_TYPE_CAMERA_DISCONNECTED =1     # SDK device disconnected exception
OB_EXCEPTION_TYPE_PLATFORM        =2      #An error in the SDK adaptation platform layer 
OB_EXCEPTION_TYPE_INVALID_VALUE     =3     #Invalid data type exception, input parameters need to be checked
OB_EXCEPTION_TYPE_WRONG_API_CALL_SEQUENCE =4   # Exception caused by API version mismatch
OB_EXCEPTION_TYPE_NOT_IMPLEMENTED    =5       # The SDK and firmware have not yet realized the function
OB_EXCEPTION_TYPE_IO              =6     # SDK access IO exception error
OB_EXCEPTION_TYPE_MEMORY          =7      # SDK access and use memory error, which means frame failed to allocate memory
OB_EXCEPTION_TYPE_UNSUPPORTED_OPERATION  =8   # Operation type error not supported by SDK or RGBD device
OB_EXCEPTION_TYPE_COUNT =9
```
**call the API**
```
getExceptionType()
```
**code example**<br />4.3.1.1code example<br />​<br />
#### 4.3.1.3 getName function
**Functional description**<br />Function function: Get the name of the interface function that threw the exception<br />parameter：<br />[in] None。<br />Return value: Returns the name of the interface function that threw the exception，data type：class bytes。<br />**call the API**
```
getName()
```
**code example**<br />4.3.1.1code example<br />**​**<br />
#### 4.3.1.4 getArgs function
**Functional description**<br />Function function: get the parameter of the function that throws an exception。<br />parameter：<br />[in] 无。<br />the parameter of the interface function that throws an exception，data type：class bytes。<br />**call the API**
```
getArgs()
```
**code example**<br />4.3.1.1code example<br />**​**<br />
#### 4.3.1.5 getStatus function
**Functional description**<br />Function function: Get the error status of SDK exception<br />parameter：<br />[in] None。<br />Return value: return error status, 0 is OK, 1 is ERROR.<br />**call the API**
```
getStatus()
```
**code example**<br />3.3.1.1code example

## 4.4 Frame API
mainly used to obtain frame data and frame information。<br />Frame class inheritance relationship：<br />​Frame<br />​|<br />+------------------------+<br />|                                     |          <br />VideoFrame           FrameSet <br />​|<br />+------------------------+----------------+<br />|                                     |                         |<br />ColorFrame          DepthFrame           IRFrame
### 4.4.1 Frame Class
The basic type of frame, the programming calls the base class method through the objects of VideoFrame, ColorFrame, DepthFrame and IRFrame class.
```
class Frame :
	Methods defined here:
	type(...)
	format(...)
	index(...)
	data(...)
	dataSize(...)
	timeStamp(...)
	systemTimeStamp(...)
```
#### 4.4.1.1 type function
**Functional description**<br />Function function: Get the type of frame.<br />parameter：<br />[in] None。<br />Return value: the type of the returned frame, data type: enum ob_py_frame_type:
```
	OB_PY_FRAME_VIDEO  = 0
    OB_PY_FRAME_IR     = 1
    OB_PY_FRAME_COLOR  = 2
    OB_PY_FRAME_DEPTH  = 3
    OB_PY_FRAME_ACCEL  = 4
    OB_PY_FRAME_SET    = 5
    OB_PY_FRAME_POINTS = 6
    OB_PY_FRAME_GYRO   = 7
```
**call the API**
```
type()
```
**code example**<br />
```
type = colorFrame.type() 
```
#### 4.4.1.2 format function
**Functional description**<br />Function function: get the format of the frame.<br />parameter：<br />[in] None。<br />Return value: the format and data type of the returned frame：enum ob_py_format:
```
    OB_PY_FORMAT_YUYV      = 0                       # YUYV 
    OB_PY_FORMAT_YUY2      = 1                       # YUY2(The actual format is the same as YUYV) 
    OB_PY_FORMAT_UYVY      = 2                       # UYVY 
    OB_PY_FORMAT_NV12      = 3                       # NV12 
    OB_PY_FORMAT_NV21      = 4                       # NV21 
    OB_PY_FORMAT_MJPG      = 5                       # MJPG 
    OB_PY_FORMAT_H264      = 6                       # H.264 
    OB_PY_FORMAT_H265      = 7                       # H.265 
    OB_PY_FORMAT_Y16       = 8                       # Y16
    OB_PY_FORMAT_Y8        = 9                       # Y8
    OB_PY_FORMAT_Y10       = 10                      # Y10
    OB_PY_FORMAT_Y11       = 11                      # Y11
    OB_PY_FORMAT_Y12       = 12                      # Y12
    OB_PY_FORMAT_GRAY      = 13                      # GRAY
    OB_PY_FORMAT_HEVC      = 14                      # HEVC(The actual format is the same as H265) 
    OB_PY_FORMAT_I420      = 15                      # I420  
    OB_PY_FORMAT_ACCEL     = 16                      # Accel Sensor Data Format 
    OB_PY_FORMAT_GYRO      = 17                      # Gyro Sensor Data Format  
    OB_PY_FORMAT_POINT     = 19                      # x-y-z three-dimensional coordinate point format  
    OB_PY_FORMAT_RGB_POINT = 20                      # x-y-z three-dimensional coordinate point format with RGB information 
    OB_PY_FORMAT_RLE       = 21                      # RLE pressure format (SDK will unpack into Y16 by default)
    OB_PY_FORMAT_RGB888    = 22                      # RGB888  
    OB_PY_FORMAT_BGR       = 23                      # BGR(BRG888) 
    OB_PY_FORMAT_Y14       = 24                      # Y14，Single channel 14bit depth (SDK will unpack into Y16 by default)
    OB_PY_FORMAT_BGRA      = 25                      # BGRA
    OB_PY_FORMAT_UNKNOWN   = 0xff                    # UNKNOWN 
```
**call the API**
```
format()
```
**code example**<br />
```
format = colorFrame.format() 
```
#### 4.4.1.3 index function
**Functional description**<br />Function function: get the number of the frame。<br />parameter：<br />[in] None。<br />Return value: the frame number , data type：unsigned long long。<br />**call the API**
```
index()
```
**code example**<br />
```
index = colorFrame.index() 
```
#### 4.4.1.4 data function
**Functional description**<br />Function function: get frame data。<br />parameter：<br />[in] None。<br />Return value: return frame data, data type：class numpy.ndarray。<br />**call the API**
```
data()
```
**code example**<br />
```
data = colorFrame.data() 
```
#### 4.4.1.5 dataSize function
**Functional description**<br />Function function: get frame data size。<br />parameter：<br />[in] None。<br />Return value: Returns the data size of the frame，data type：unsigned int。<br />**call the API**
```
dataSize()
```
**code example**<br />
```
size = colorFrame.dataSize() 
```
#### 4.4.1.6 timeStamp function
**Functional description**<br />Function function: get the hardware timestamp of the frame。<br />parameter：<br />[in] None。<br />Return value: Returns the hardware timestamp of the frame，data type：unsigned long long。<br />**call the API**
```
timeStamp()
```
**code example**<br />
```
stamp = colorFrame.timeStamp() 
```
#### 4.4.1.7 systemTimeStamp function
**Functional description**<br />Function function: get the system timestamp of the frame。<br />parameter：<br />[in] None。<br />Return value: The system timestamp of the returned frame，data type：unsigned long long。<br />**call the API**
```
systemTimeStamp()
```
**code example**<br />
```
stamp = colorFrame.systemTimeStamp() 
```
### 4.4.2 VideoFrame Class
VideoFrame inherited from the Frame class
```
class VideoFrame ( Frame ):
	Methods defined here:
	width(...)
	height(...)
	metadata(...)
	metadataSize(...)
	Other Methods inherited from Frame
	type(...)
	format(...)
	index(...)
	data(...)
	dataSize(...)
	timeStamp(...)
	systemTimeStamp(...)
```
Here only the methods defined by the VideoFrame class are described, and other methods are inherited from Frame.

#### 4.4.2.1 width function
**Functional description**<br />Function function: get the width of the frame。<br />parameter：<br />[in] None。<br />Return value: returns the width of the frame，data type：int。<br />**call the API**
```
width()
```
**code example**<br />
```
width = colorFrame.width() 
```
#### 4.4.2.2 height function
**Functional description**<br />Function function: get the height of the frame。<br />parameter：<br />[in] None。<br />Return value: returns the height of the frame，data type：int。<br />**call the API**
```
height()
```
**code example**<br />
```
height = colorFrame.height() 
```
#### 4.4.2.3 metadata function
**Functional description**<br />Function function: get the metadata of the frame。<br />parameter：<br />[in] None。<br />Return value: returns the metadata of the frame，data type：class numpy.ndarray。<br />**call the API**
```
metadata()
```
**code example**<br />
```
data = colorFrame.metadata() 
```
#### 4.4.2.4 metadataSize function
**Functional description**<br />Function function: get the metadata size of the frame。<br />parameter：<br />[in] None。<br />Return value: returns the metadata size of the frame，data type：unsigned int。<br />**call the API**
```
metadataSize()
```
**code example**<br />
```
size = colorFrame.metadataSize() 
```
### 4.4.3 ColorFrame Class
ColorFrame，inherited from the VideoFrame 
```
class ColorFrame( VideoFrame ):
	Other Methods inherited from VideoFrame 
	width(...)
	height(...)
	metadata(...)
	metadataSize(...)
	type(...)
	format(...)
	index(...)
	data(...)
	dataSize(...)
	timeStamp(...)
	systemTimeStamp(...)

```
### 4.4.4 DepthFrame Class
DepthFrame，inherited from the VideoFrame 
```
class DepthFrame( VideoFrame ):
	Methods defined here:
	getValueScale(...)
	Other Methods inherited from VideoFrame 
	width(...)
	height(...)
	metadata(...)
	metadataSize(...)
	type(...)
	format(...)
	index(...)
	data(...)
	dataSize(...)
	timeStamp(...)
	systemTimeStamp(...)
```
Here only the methods defined by the DepthFrame class are described, and other methods are inherited from VideoFrame.
#### getValueScale function
**Functional description**<br />Function function: Get the unit of the depth frame，<br />For example, valueScale=0.1, the pixel value of a certain coordinate is pixelValue=10000,<br />It means the depth value = pixelValue*valueScale = 10000*0.1=1000mm.<br />parameter：<br />[in] None。<br />Return Value: Returns the value scale of the depth frame，data type：float。<br />**call the API**
```
getValueScale()
```
**code example**<br />
```
scale = depthFrame.getValueScale() 
```
### 4.4.5 IRFrame Class
IRFrame，inherited from the VideoFrame 
```
class IRFrame( VideoFrame ):
	Other Methods inherited from VideoFrame 
	width(...)
	height(...)
	metadata(...)
	metadataSize(...)
	type(...)
	format(...)
	index(...)
	data(...)
	dataSize(...)
	timeStamp(...)
	systemTimeStamp(...)
```
### 4.4.6 FrameSet Class
FrameSet，inherited from the VideoFrame 
```
class FrameSet( Frame ):
	Methods defined here:
	frameCount(...)
	depthFrame(...)
	colorFrame(...)
	irFrame(...)
	getFrame(...)
	Other Methods inherited from Frame 
	type(...)
	format(...)
	index(...)
	data(...)
	dataSize(...)
	timeStamp(...)
	systemTimeStamp(...)
```
Here only the methods defined by the FrameSet class are described, and other methods are inherited from Frame.
#### 4.4.6.1 frameCount function
**Functional description**<br />Function function: the number of frames contained in the frameset。<br />parameter：<br />[in] None。<br />Return value: the number of frames contained in the frameset，data type：int。<br />**call the API**
```
frameCount()
```
**code example**<br />
```
num = frameSet.frameCount() 
```
#### 4.4.6.2 depthFrame function
**Functional description**<br />Function function: get the depth frame。<br />parameter：<br />[in] None。<br />Return value: returns the depth frame，data type：class DepthFrame。<br />**call the API**
```
depthFrame()
```
**code example**<br />
```
depthFrame = frameSet.depthFrame() 
```
#### 4.4.6.3 colorFrame function
**Functional description**<br />Function function: get the color frame。<br />parameter：<br />[in] None。<br />Return value: returns the color frame，data type：class ColorFrame。<br />**call the API**
```
colorFrame()
```
**code example**<br />
```
colorFrame = frameSet.colorFrame()
```
#### 4.4.6.4 irFrame function
**Functional description**<br />Function function: get the ir frame。<br />parameter：<br />[in] None。<br />Return value: returns the ir frame，data type：class IRFrame。<br />**call the API**
```
irFrame()
```
**code example**<br />
```
irFrame = frameSet.irFrame() 
```
#### 4.4.6.5 getFrame function
**Functional description**<br />Function function: Get frame by sensor type.<br />parameter：<br />[in] sensorType,sensor type，data type：enum ob_py_sensor_type:<br />	OB_PY_SENSOR_UNKNOWN = 0<br />	OB_PY_SENSOR_IR      = 1<br />	OB_PY_SENSOR_COLOR   = 2<br />	OB_PY_SENSOR_DEPTH   = 3<br />Return value: returns the frame of the corresponding type，data type：class ColorFrame,class DepthFrame,class IrFrame。<br />**call the API**
```
getFrame( sensorType )
```
**code example**<br />
```
colorFrame = frameSet.getFrame( Frame.OB_PY_SENSOR_COLOR ) 
```
## 4.5 Pipeline API
The advanced API type of the SDK can quickly realize switch flow and frame synchronization
### 4.5.1 Pipeline Class
Pipeline is the high-level interface of SDK. Pipeline can provide aligned and synchronized FrameSet frame collection inside SDK, which is convenient for customers to use.
```
class Pipeline:
	Methods defined here:
	start(...)
	startWithCallback(...)
	stop(...)
	getConfig(...)
	waitForFrames(...)
	getDevice(...)
	getStreamProfileList(...)
	getAllStreamProfileList(...)
	enableFrameSync(...)
	disableFrameSync(...)

```
#### 4.5.1.1 init function
**Functional description**<br />Function function: Create a Pipeline.
<br />parameter：<br />[in] device,data type：class Device。
<br />[in] fileName:The path of the playback video file。
<br /> 1.device is None, fileName is None, and the first device in the device list connected to the host computer is opened by default. If the application has acquired the device through DeviceList, opening Pipeline() will throw an exception that the device has been created, and the developer needs to catch the exception and handle it.
<br />  2.The device is not None, and the fileName is None, which is suitable for multi-device operation scenarios. In this case, multiple devices need to be obtained through DeviceList, and the device and pipeline are bound through this interface.
<br />  3.device is None, fileName is not None, fileName is the path of the playback file, and a pipeline is created to play back the recorded file
<br />Return value: Returns the object of the Pipeline class。<br />**call the API**
```
Pipeline( dev,None )
```
**code example**
```
The parameter is None:
pipe = Pipeline.Pipeline( None,None )
Parameter is not None:
ctx = Context.Context( None )
devList = ctx.queryDeviceList()
dev = devList.getDevice( 0 )
pipe = Pipeline.Pipeline( dev,None )
```
#### 4.5.1.2 start function
**Functional description**<br />Function function: start the pipeline and configure parameters。<br />parameter：<br />[in] config: Pipeline parameter configuration,data type：class Config。<br />Return value: None。<br />**call the API**
```
start( config)
```
**code example**<br />
```
pipe.start( config ) 
```
#### 4.5.1.3 startWithCallback function
**Functional description**<br />Function function: start the pipeline and set the frameset data callback。<br />parameter：<br />[in] config: Pipeline parameter configuration,data type：class Config。
<br />[in] callback: Set the callback to be triggered when all the frame data in the frameset arrive. The python callback function: def callback( frameSet ), the data type of frameSet is class FrameSet
<br />Return value: None。<br />**call the API**
```
startWithCallback( config, callback )
```
**code example**<br />
```
def callback( frameSet ):
print(“callback”)
pipe.start( config，callback ) 
```
#### 4.5.1.4 stop function
**Functional description**<br />Function function: stop pipeline。<br />parameter：<br />[in] None。<br />Return value: None。<br />**call the API**
```
stop()
```
**code example**<br />
```
pipe.stop() 
```
#### 4.5.1.5 getConfig function
**Functional description**<br />Function function: get the config parameters of the pipeline。<br />parameter：<br />[in] None。<br />Return value: Returns the config parameters, data type：class Config。<br />**call the API**
```
getConfig()
```
**code example**<br />
```
cfg = pipe.getConfig() 
```
#### 4.5.1.6 waitForFrames function
**Functional description**<br />Function function: wait for frameset data。<br />parameter：<br />[in] timeout: wait timeout (milliseconds)，data type：int。<br />Return value: return the waiting frameset，data type：class FrameSet。<br />**call the API**
```
waitForFrames( timeout )
```
**code example**<br />
```
frameSet = pipe.waitForFrames( 100 ) 
```
#### 4.5.1.7 getDevice function
**Functional description**<br />Function function: get the device object.<br />parameter：<br />[in] None。<br />Return value: return device object, data type：class Device。<br />**call the API**
```
getDevice()
```
**code example**<br />
```
dev = pipe.getDevice() 
```
#### 4.5.1.8 getStreamProfileList function
**Functional description**<br />Function function: Get the stream profile list of the specified sensor。<br />parameter：<br />[in] sensorType，sensor type，data type：enum ob_py_sensor_type:<br />	OB_PY_SENSOR_UNKNOWN = 0<br />	OB_PY_SENSOR_IR      = 1<br />	OB_PY_SENSOR_COLOR   = 2<br />	OB_PY_SENSOR_DEPTH   = 3
<br />Return value: return stream profile list, data type：class StreamProfileList。<br />**call the API**
```
getStreamProfileList( sensorType )
```
**code example**<br />
```
profiles = pipe.getStreamProfileList( Pipeline.OB_PY_SENSOR_COLOR ) 
```
#### 4.5.1.9 getPlayback function
**Functional description**<br />Function function: get the playback object。<br />parameter：<br />[in] None。<br />Return value: returns the playback object。<br />**call the API**
```
getPlayback()
```

**code example**<br />
```
playback = pipe.getPlayback()
```
#### 4.5.1.10 enableFrameSync function
**Functional description**<br />Function function: Enable the frame synchronization。<br />parameter：<br />[in] None。<br />Return value: None。<br />**call the API**
```
enableFrameSync()
```
**code example**<br />
```
pipe.enableFrameSync() 
```
#### 4.5.1.11 disableFrameSync function
**Functional description**<br />Function function: disable the frame synchronization。<br />parameter：<br />[in] None。<br />Return value: None。<br />**call the API**
```
disableFrameSync()
```
**code example**<br />
```
pipe.disableFrameSync() 
```

#### 4.5.1.12 getCameraParam function
**Functional description**<br />Function function: Get camera parameters, if D2C is enabled, it will return the camera parameters after D2C, if not, it will return the default parameters。<br />parameter：<br />[in] None。<br />Return value: returns camera parameters。<br />**call the API**
```
getCameraParam()
```
**code example**<br />
```
pipe.getCameraParam() 
```

#### 4.5.1.13 startRecord function
**Functional description**<br />Function function: start recording。<br />parameter：<br />[in] filename：The file name of the record file, data type: const char *。<br />Return value：None。<br />**call the API**
```
startRecord(filename)
```
**code example**<br /> 
```
 pipe.startRecord('./OrbbecPipeline.bag') 
```

#### 4.5.1.13 stopRecord function
**Functional description**<br />Function function: stop recording。<br /><br />Return value: None。<br />**call the API**
```
stopRecord()
```
**code example**<br />
```
 pipe.stopRecord()  
```

### 4.5.2 Config class
Set the stream configuration to open
```
class Config:
	Methods defined here:
	enableStream(...)
	enableAllStream(...)
	disableStream(...)
	disableAllStream(...)
	setAlignMode（...）
```
#### 4.5.2.1 enableStream function
**Functional description**<br />Function function: set the stream configuration to be opened。<br />parameter：<br />[in] profile:stream profile，data type：class VideoStreamProfile。<br />return value：None。<br />**call the API**
```
enableStream( profile )
```
**code example**<br />
```
config.enableStream( colorProfile ) 
```
#### 4.5.2.2 enableAllStream function
**Functional description**<br />Function function: enable all streams。<br />parameter：<br />[in] None。<br />return value：None。<br />**call the API**
```
enableAllStream()
```
**code example**<br />
```
config.enableAllStream() 
```
#### 4.5.2.3 disableStream function
**Functional description**<br />Function function: disable stream。<br />parameter：<br />[in] streamType: stream type，data type：enum ob_py_stream_type:
<br />	OB_PY_STREAM_VIDEO = 0<br />	OB_PY_STREAM_IR    = 1<br />	OB_PY_STREAM_COLOR = 2<br />	OB_PY_STREAM_DEPTH = 3<br />return value：None。<br />**call the API**
```
disableStream( streamType )
```
**code example**<br />
```
config.disableStream( Pipeline.OB_PY_STREAM_COLOR) 
```
#### 4.5.2.4 disableAllStream function
**Functional description**<br />Function function: disable all streams。<br />parameter：<br />[in] None。<br />return value：None。<br />**call the API**
```
disableStream()
```
**code example**<br />
```
config.disableStream() 
```

#### 4.5.2.4 setAlignMode function
**Functional description**<br />Function function: set the alignment mode。<br />parameter：<br />[in] mode：the alignment mode。<br />return value：None。<br />**call the API**
```
setAlignMode(mode)
```
**code example**<br />
```
config.setAlignMode(OB_PY_ALIGN_D2C_HW_MODE)
```

## 4.6 Sensor API

Sensor-related types, used to obtain stream configuration, switch stream, set and get sensor properties, etc.
### 4.6.1 Sensor Class

```
class Sensor :
	Methods defined here:
	type(...)
	getStreamProfileList(...)
	start(...)
	stop(...)
```
#### 4.6.1.1 type function
**Functional description**<br />Function function: sensor type。<br />parameter：<br />[in] None。<br />Return value: return sensor type，enum ob_py_sensor_type:
<br />	OB_PY_SENSOR_UNKNOWN = 0<br />	OB_PY_SENSOR_IR      = 1<br />	OB_PY_SENSOR_COLOR   = 2<br />	OB_PY_SENSOR_DEPTH   = 3<br />**call the API**
```
type()
```
**code example**
```
ctx = Context.Context( None )
devList = ctx.queryDeviceList()
dev = devList.getDevice( 0 )
sensorList = dev.getSensorList()
sensor = sensorList.getSensorByType( Sensor.OB_PY_SENSOR_COLOR )
type = sensor.type()
```

#### 4.6.1.2 getStreamProfileList function
**Functional description**<br />Function function: Get the stream profile list of the sensor。<br />parameter：<br />[in] None。<br />Return value: return stream profile list，data type：class StreamProfileList。<br />**call the API**
```
getStreamProfileList()
```
**code example**
```
profiles = sensor.getStreamProfileList() 
```
#### 4.6.1.3 start function
**Functional description**<br />Function function: open the stream and set the frame data callback。<br />parameter：<br />[in] streamProfile: stream profile，data type：class StreamProfile。
<br />[in] callback: Set the callback when the frame data arrives, python's callback function def callback( frame ), the data type of frame is class Frame。<br />Return value: None<br />**call the API**
```
start( streamProfile, callback )
```
**code example**
```
def callback( frame ):
print(“callback”)
profiles = sensor.getStreamProfileList()  
count = profiles.count()
for i in range( count ):
	profile = profiles.getProfile( i )
	videoProfile = profile.toViedo()
	if videoProfile.format() == StreamProfile.PY_FORMAT_MJPG:
		colorProfile = videoProfile
		break
sensor.start( profile,callback ) 
```
#### 4.6.1.4 stop function
**Functional description**<br />Function function: stop stream。<br />parameter：<br />[in] None。<br />Return value: None。<br />**call the API**
```
stop()
```
**code example**
```
sensor.stop()   
```
### 4.6.2 SensorList Class
sensor list<br />class SensorList :<br />Methods defined here:<br />	count(...)<br />	type(...)<br />	getSensorByIndex(...)<br />	getSensorByType(...)
#### 4.6.2.1 count function 
**Functional description**<br />Function function: Get the number of Sensors。<br />parameter：<br />[in] None。<br />Return value: Return the number of Sensors，data type：int。<br />**call the API**
```
count()
```
**code example**
```
ctx = Context.Context( None )
devList = ctx.queryDeviceList()
dev = devList.getDevice( 0 )
sensorList = dev.getSensorList()
num = sensorList.count()
```
#### 4.6.2.2 type function
**Functional description**<br />Function function: Get the type of the specified Sensor。<br />parameter：<br />[in] index: Sensor index，data type：int。<br />Return value: return Sensor type，data type：enum ob_py_sensor_type:
<br />	OB_PY_SENSOR_UNKNOWN = 0<br />	OB_PY_SENSOR_IR      = 1<br />	OB_PY_SENSOR_COLOR   = 2<br />	OB_PY_SENSOR_DEPTH   = 3<br />**call the API**
```
type( index )
```
**code example**
```
type = sensorList.type( 0 )  
```
#### 4.6.2.3 getSensorByIndex function
**Functional description**<br />Function function: Get Sensor by index number。<br />parameter：<br />[in] index: Sensor index，data type：int。<br />Return value：Return Sensor object, data type：class Sensor。<br />**call the API**
```
getSensorByIndex( index )
```
**code example**
```
sensor = sensorList.getSensorByIndex( 0 )   
```
#### 4.6.2.4 getSensorByType function
**Functional description**<br />Function function: Get the Sensor through the Sensor type。<br />parameter：<br />[in] sensorType: Sensor type , data type：enum ob_py_sensor_type:
<br />	OB_PY_SENSOR_UNKNOWN = 0<br />	OB_PY_SENSOR_IR      = 1<br />	OB_PY_SENSOR_COLOR   = 2<br />	OB_PY_SENSOR_DEPTH   = 3<br />Return value: return Sensor object, data type：class Sensor。<br />**call the API**
```
getSensorByType( sensorType )
```
**code example**
```
sensor = sensorList.getSensorByType( Sensor.OB_PY_SENSOR_COLOR ) 
```
## 4.7 StreamProfile API
### 4.7.1 StreamProfile class
Stream Profile class<br />class StreamProfile:<br />Methods defined here:<br />	format(...)<br />	type(...)<br />	toViedo(...)
#### 4.7.1.1 format function
**Functional description**<br />Function function: get the format of the stream。<br />parameter：<br />[in] None。<br />Return value:  get the format of the stream，data type：enum ob_py_format:
```
    OB_PY_FORMAT_YUYV      = 0                       # YUYV 
    OB_PY_FORMAT_YUY2      = 1                       # YUY2(The actual format is the same as YUYV) 
    OB_PY_FORMAT_UYVY      = 2                       # UYVY 
    OB_PY_FORMAT_NV12      = 3                       # NV12 
    OB_PY_FORMAT_NV21      = 4                       # NV21 
    OB_PY_FORMAT_MJPG      = 5                       # MJPG 
    OB_PY_FORMAT_H264      = 6                       # H.264 
    OB_PY_FORMAT_H265      = 7                       # H.265 
    OB_PY_FORMAT_Y16       = 8                       # Y16
    OB_PY_FORMAT_Y8        = 9                       # Y8
    OB_PY_FORMAT_Y10       = 10                      # Y10
    OB_PY_FORMAT_Y11       = 11                      # Y11
    OB_PY_FORMAT_Y12       = 12                      # Y12
    OB_PY_FORMAT_GRAY      = 13                      # GRAY
    OB_PY_FORMAT_HEVC      = 14                      # HEVC(The actual format is the same as H265) 
    OB_PY_FORMAT_I420      = 15                      # I420  
    OB_PY_FORMAT_ACCEL     = 16                      # Accel Sensor Data Format 
    OB_PY_FORMAT_GYRO      = 17                      # Gyro Sensor Data Format  
    OB_PY_FORMAT_POINT     = 19                      # x-y-z three-dimensional coordinate point format  
    OB_PY_FORMAT_RGB_POINT = 20                      # x-y-z three-dimensional coordinate point format with RGB information 
    OB_PY_FORMAT_RLE       = 21                      # RLE pressure format (SDK will unpack into Y16 by default)
    OB_PY_FORMAT_RGB888    = 22                      # RGB888  
    OB_PY_FORMAT_BGR       = 23                      # BGR(BRG888) 
    OB_PY_FORMAT_Y14       = 24                      # Y14，Single channel 14bit depth (SDK will unpack into Y16 by default)
    OB_PY_FORMAT_BGRA      = 25                      # BGRA
    OB_PY_FORMAT_UNKNOWN   = 0xff                    # UNKNOWN 
```
**call the API**
```
format()
```
**code example**
```
format = profile.format() 
```
#### 4.7.1.2 type function
**Functional description**<br />Function function: get the type of stream。<br />parameter：<br />[in] None。<br />Return value: the type of stream，data type：enum ob_py_stream_type:
<br />	OB_PY_STREAM_VIDEO = 0<br />	OB_PY_STREAM_IR    = 1<br />	OB_PY_STREAM_COLOR = 2<br />	OB_PY_STREAM_DEPTH = 3<br />**call the API**
```
type()
```
**code example**
```
type = profile.type() 
```

### 4.7.2 VideoStreamProfile Class
Video stream profile
```
class VideoStreamProfile( StreamProfile ):
	Methods defined here:
	fps(self)
	width(self)
	height(self)
	Other Methods inherited from StreamProfile 
	format(...)
	type(...)
```
Here only the methods defined by the VideoStreamProfile class are described, and other methods are inherited from StreamProfile.
#### 4.7.2.1 fps function
**Functional description**<br />Function function: get the frame rate of the stream。<br />parameter：<br />[in] None。<br />Return value: Returns the frame rate of the stream，data type：int。<br />**call the API**
```
fps()
```
**code example**
```
fps = videoProfile.fps() 
```
#### 4.7.2.2 width function
**Functional description**<br />Function function: get width。<br />parameter：<br />[in] None 。<br />Return value: the width of the stream，data type：int。<br />**call the API**
```
width()
```
**code example**
```
width = videoProfile.width() 
```
#### 4.7.2.3 height function
**Functional description**<br />Function function: get height <br />parameter：<br />[in] None。<br /> Return value: the height of the stream，data type：int <br />**call the API**
```
height()
```
**code example**
```
height = videoProfile.height() 
```
### 4.7.3 StreamProfileList Class
<br />class StreamProfileList:<br />Methods defined here:<br />count(...)<br />getProfile(...)
#### 4.7.3.1 count function
**Functional description**<br />Function function: Get the number of StreamProfile。<br />parameter：<br />[in] None。<br />Return value: return the number of StreamProfile, data type：int。<br />**call the API**
```
count()
```
**code example**
```
num = profiles.count() 
```
#### 4.7.3.2 getProfile function
**Functional description**<br />Function function: Get StreamProfile by index 。<br />parameter：<br />[in] index：index number，data type：int。<br />Return value: return StreamProfile object，data type：class StreamProfile。<br />**call the API**
```
getProfile( index )
```
**code example**
```
profile = profiles.getProfile( 0 ) 
```

#### 4.7.3.3 getVideoStreamProfile function
**Functional description**<br />Function function: match the corresponding StreamProfile through the incoming parameters, if there are multiple matching items, return the first one in the list by default。
<br />parameter：<br />[in] width，image width。
<br />parameter：<br />[in] height，image height。
<br />parameter：<br />[in] format，frame format。
<br />parameter：<br />[in] fps，frame rate。
<br />Return value: StreamProfile returns the matching stream profile。<br />**call the API**
```
getVideoStreamProfile( width,height,format,fps )
```
**code example**
```
profile = profiles.getVideoStreamProfile(640,480,OB_PY_FORMAT_Y16,30)
```

## 4.8 Version API
获取SDK版本号相关信息的类
### 4.8.1 Version Class
<br />class Version:<br />Methods defined here:<br />	getMajor(...)<br />	getMinor(...)<br />	getPatch(...)<br />	getVersion(...)<br />	getWrapperVersion(...)
#### 4.8.1.1 getMajor function
**Functional description**<br />Function function: Get the main version number of the SDK。<br />parameter：<br />[in] None。<br />Return value: return SDK major version number，data type：int。<br />**call the API**
```
getMajor()
```
**code example**
```
version= Version.Version()
print( "SDK version: %d.%d.%d" \
	%( version.getMajor(), version.getMinor(), version.getPatch() ) )
print("Version ",version.getVersion())
print("WrapperVersion ",version.getWrapperVersion())
```
#### 4.8.1.2 getMinor function
**Functional description**<br />Function function: Get the minor version number of the SDK。<br />parameter：<br />[in] None。<br />Return value: return SDK minor version number，data type：int。<br />**call the API**
```
getMinor()
```
**code example**<br /> refer to 4.8.1.1 code example<br />**​**<br />
#### 4.8.1.3 getPatch function
**Functional description**<br />Function function: Get the SDK revision number。<br />parameter：<br />[in] None。<br />Return value: Returns the SDK revision number，data type：int。<br />**call the API**
```
getPatch()
```
**code example**<br /> refer to 4.8.1.1 code example<br />​<br />
#### 4.8.1.4 getVersion function
**Functional description**<br />Function function: get SDK version number。<br />parameter：<br />[in] None。<br />Return value: return SDK version number，data type：int。<br />**call the API**
```
getVersion()
```
**code example**<br /> refer to 4.8.1.1 code example<br />​<br />
#### 4.8.1.5 getWrapperVersion function
**Functional description**<br />Function function: get the version number of Python Wrapper SDK。<br />parameter：<br />[in] None。<br />Return value: Returns the version number of the Python Wrapper SDK，data type：class str。<br />**call the API**
```
getWrapperVersion()
```
**code example**<br /> refer to 4.8.1.1 code example
## 4.9 data type definition
enum definition
### 4.9.1 ob_py_property_id
```
In the Device modules, attribute definitions are used to get and set the attributes of device 
enum ob_py_property_id:
    # 0~999 are int, bool and float type control commands on the device
    # Device:: get/setxxxProperty、 getxxxPropertyRange (xxx Data Type)
    OB_PY_PROP_LDP_BOOL                              = 2                       # LDP switch 
    OB_PY_PROP_LASER_BOOL                            = 3                       # laser switch 
    OB_PY_PROP_LASER_PULSE_WIDTH_INT                 = 4                       # laser pulse width
    OB_PY_PROP_LASER_CURRENT_FLOAT                   = 5                       # laser current 
    OB_PY_PROP_FLOOD_BOOL                            = 6                       # flood switch
    OB_PY_PROP_FLOOD_LEVEL_INT                       = 7                       # flood level
    OB_PY_PROP_DEPTH_MIRROR_BOOL                     = 14                      # depth mirror 
    OB_PY_PROP_DEPTH_FLIP_BOOL                       = 15                      # depth flip 
    OB_PY_PROP_DEPTH_POSTFILTER_BOOL                 = 16                      # Depth Postfilter 
    OB_PY_PROP_DEPTH_HOLEFILTER_BOOL                 = 17                      # Depth Holefilter 
    OB_PY_PROP_IR_MIRROR_BOOL                        = 18                      # IR mirror 
    OB_PY_PROP_IR_FLIP_BOOL                          = 19                      # IR flip 
    OB_PY_PROP_MIN_DEPTH_INT                         = 22                      # min depth value 
    OB_PY_PROP_MAX_DEPTH_INT                         = 23                      # man depth value  
    OB_PY_PROP_DEPTH_SOFT_FILTER_BOOL                = 24                      # soft filter switch 
    OB_PY_PROP_LDP_STATUS_BOOL                       = 32                      # LDP status
    OB_PY_PROP_DEPTH_MAX_DIFF_INT                    = 40                      # soft filter maxdiff param 
    OB_PY_PROP_DEPTH_MAX_SPECKLE_SIZE_INT            = 41                      # soft filter maxSpeckleSize 
    OB_PY_PROP_DEPTH_ALIGN_HARDWARE_BOOL             = 42                      # Hardware d2c switch
    OB_PY_PROP_TIMESTAMP_OFFSET_INT                  = 43                      # Timestamp adjustment 
    OB_PY_PROP_HARDWARE_DISTORTION_SWITCH_BOOL       = 61                      # hardware distortion switch(Rectify)  
    OB_PY_PROP_FAN_WORK_MODE_INT                     = 62                      # Fan switch mode 
    OB_PY_PROP_DEPTH_ALIGN_HARDWARE_MODE_INT         = 63                      # Multi-resolution D2C mode 

    OB_PY_PROP_COLOR_MIRROR_BOOL          = 81                                 # Color mirror
    OB_PY_PROP_COLOR_FLIP_BOOL            = 82                                 # Color flip 


    OB_PY_PROP_COLOR_AUTO_EXPOSURE_BOOL         = 2000                         # color auto exposure switch
    OB_PY_PROP_COLOR_EXPOSURE_INT               = 2001                         # color exposure 
    OB_PY_PROP_COLOR_GAIN_INT                   = 2002                         # color gain 
    OB_PY_PROP_COLOR_AUTO_WHITE_BALANCE_BOOL    = 2003                         # color auto white balance switch
    OB_PY_PROP_COLOR_WHITE_BALANCE_INT          = 2004                         # color white balance 
    OB_PY_PROP_COLOR_BRIGHTNESS_INT             = 2005                         # color brightness 
    OB_PY_PROP_COLOR_SHARPNESS_INT              = 2006                         # color sharpness
    OB_PY_PROP_COLOR_SATURATION_INT             = 2008                         # color saturation  
    OB_PY_PROP_COLOR_CONTRAST_INT               = 2009                         # color contrast
    OB_PY_PROP_COLOR_GAMMA_INT                  = 2010                         # color gamma
    OB_PY_PROP_COLOR_ROLL_INT                   = 2011                         # color roll 
    OB_PY_PROP_COLOR_AUTO_EXPOSURE_PRIORITY_INT = 2012                         # color camera auto exposure priority
    OB_PY_PROP_COLOR_BACKLIGHT_COMPENSATION_INT = 2013                         # color backlight compensation
    OB_PY_PROP_COLOR_HUE_INT                    = 2014                         # color hue 
    OB_PY_PROP_COLOR_POWER_LINE_FREQUENCY_INT   = 2015                         # color camera power line frequency 
    OB_PY_PROP_DEPTH_AUTO_EXPOSURE_BOOL         = 2016                         # Depth camera automatic exposure (ir camera will be set synchronously on some models of devices)
    OB_PY_PROP_DEPTH_EXPOSURE_INT               = 2017                         # Depth camera exposure adjustment (ir camera will be set synchronously on some models of devices)
    OB_PY_PROP_DEPTH_GAIN_INT                   = 2018                         # Depth camera gain adjustment (ir camera will be set synchronously on some models of devices)
    OB_PY_PROP_IR_AUTO_EXPOSURE_BOOL            = 2025                         # ir camera automatic exposure (the depth camera will be set synchronously under some models of devices) 
    OB_PY_PROP_IR_EXPOSURE_INT                  = 2026                         # ir camera exposure adjustment (the depth camera will be set synchronously on some models of devices)
    OB_PY_PROP_IR_GAIN_INT                      = 2027                         # ir camera gain adjustment (the depth camera will be set synchronously on some models of devices)

    OB_PY_PROP_SDK_DEPTH_FRAME_UNPACK_BOOL = 3007                              # Depth data unpacking function switch (it will be turned on by default every time the stream is opened, and supports RLE/Y10/Y11/Y12/Y14 format)
    OB_PY_PROP_SDK_IR_FRAME_UNPACK_BOOL    = 3008                              # Ir data unpacking function switch (it will be turned on by default every time the stream is opened, and supports RLE/Y10/Y11/Y12/Y14 format)

# @brief 
cpdef enum ob_py_property_type:
    OB_PY_BOOL_PROPERTY   = 0                                                  # bool property 
    OB_PY_INT_PROPERTY    = 1                                                  # int property
    OB_PY_FLOAT_PROPERTY  = 2                                                  # float property
    OB_PY_STRUCT_PROPERTY = 3                                                  # struct type property
```

## 4.10 FAQ
```

1. ImportError: libpython3.7m.so.1.0: cannot open shared object file: No such file or directory？

Solution: 
sudo apt-get install libpython3.7


2. X Error
X Error: BadAccess (attempt to access private resource denied) 10
  Extension:    131 (MIT-SHM)
  Minor opcode: 1 (X_ShmAttach)
  Resource id:  0x12f
X Error: BadShmSeg (invalid shared segment parameter) 128
  Extension:    131 (MIT-SHM)
  Minor opcode: 5 (X_ShmCreatePixmap)
  Resource id:  0x2c0000d


Solution: Configure environment variables as follows
1. sudo vi /etc/environment
2. QT_X11_NO_MITSHM=1
3. source /etc/environment

```