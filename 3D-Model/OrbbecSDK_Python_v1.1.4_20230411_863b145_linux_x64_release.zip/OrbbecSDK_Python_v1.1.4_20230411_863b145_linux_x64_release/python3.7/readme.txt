1. 中文说明
本软件编译开发环境为：
Python 3.7.7
Cython        0.29.26 
numpy         1.21.5  
opencv-python 4.5.4.60


测试安装Python3.7的任意版本，Cython无需安装，numpy版本1.21.0及以上，opencv-python版本4.2.0.32及以上

2. English description
The software compilation and development environment is:
Python 3.7.7
Cython 0.29.26
numpy 1.21.5
opencv-python 4.5.4.60


Test and install any version of Python3.7, Cython does not need to be installed, numpy version 1.21.0 and above, opencv-python version 4.2.0.32 and above